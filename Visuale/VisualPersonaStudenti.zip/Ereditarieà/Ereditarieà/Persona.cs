﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ereditarieà
{
    internal class Persona
    {
        string nome;
        string cognome;
        public override string ToString()
        {
            return string.Format($"nome: {Nome}, cognome: {Cognome}");
        }
        public Persona()
        {
            nome = "Federico";
        }
        public Persona(string nome, string cognome)
        {
            Nome = nome;
            Cognome = cognome;
        }
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        public string Cognome
        {
            get { return cognome; }
            set { cognome = value; }
        }
        public static bool operator == (Persona p1, Persona p2)
        {
            return p1.nome == p2.nome && p1.cognome == p2.cognome;
        }
        public static bool operator !=(Persona p1, Persona p2)
        {
            return !(p1 == p2);
        }
        public bool cont(string nome, string cognome)
        {
            return nome == Nome && cognome == Cognome;
        }
    }
}
