﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ereditarieà
{
    internal class Studente : Persona
    {
        static int numMatricola = 0;
        int matricola;
        public override string ToString()
        {
            return string.Format($"nome:{Nome}, cognome:{Cognome}, matricola{matricola}");
        }
        public Studente() 
        {
            matricola = numMatricola;
            numMatricola++;
        }
        public Studente(string nome, string cognome) : base(nome, cognome)
        {
            numMatricola++;
            matricola = numMatricola;
        }
        public int Matricola 
        {
            get { return matricola; }
            set { matricola = value; }
        }
        static public int NMatricola
        {
            get { return numMatricola; }
            set { numMatricola = value; }
        }
    }
}
