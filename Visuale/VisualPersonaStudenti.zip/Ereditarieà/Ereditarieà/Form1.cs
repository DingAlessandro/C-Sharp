﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ereditarieà
{
    public partial class Ereditarietà : Form
    {
        int type = 0;
        List<Persona> persona = new List<Persona>();
        List<Studente> studente = new List<Studente>();
        public Ereditarietà()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void topolinoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ereditarietàToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void personaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (type != 1)
            {
                label3.Text = "Inserisci la persona";
                type = 1;
                Enable();
            }
        }

        private void studenteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (type != 2)
            {
                label3.Text = "Inserisci lo studente";
                type = 2;
                Enable();
            }
        }
        private void Enable() 
        {
            textBox1.Enabled = true;
            textBox2.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool t = false;
            for(int i = 0; i < textBox1.Text.Length; i++) 
            {
                if (char.IsLetter(textBox1.Text[i]))
                {
                    t = true;
                }
                if (char.IsNumber(textBox1.Text[i]))
                {
                    t = false;
                }
            }
            for (int i = 0; i < textBox2.Text.Length; i++)
            {
                if (char.IsLetter(textBox2.Text[i]))
                {
                    t = true;
                }
                if (char.IsNumber(textBox2.Text[i]))
                {
                    t = false;
                }
            }
            if (t)
            {
                if (type == 1)
                {
                    Persona p = new Persona(textBox1.Text, textBox2.Text);
                    if (persona.Count != 0)
                    {
                        t = true;
                        foreach(Persona persona in persona) 
                        {
                            if(persona == p) 
                            {
                                t = false;
                            }
                        }
                        foreach (Studente studente in studente)
                        {
                            if (studente.cont(p.Nome, p.Cognome))
                            {
                                t = false;
                            }
                        }
                        if (t) 
                        {
                            persona.Add(p);
                        }
                    }
                    else
                    {
                        persona.Add(p);
                    }
                    if (t)
                    {
                        listBox1.Items.Add(p.ToString());
                    }
                    else 
                    {
                        MessageBox.Show("Persona già inserita", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else 
                {
                    Studente p = new Studente(textBox1.Text, textBox2.Text);
                    if (studente.Count != 0)
                    {
                        t = true;
                        foreach (Studente studente in studente)
                        {
                            if (studente == p)
                            {
                                t = false;
                            }
                        }
                        foreach (Persona persona in persona)
                        {
                            if (persona.cont(p.Nome, p.Cognome))
                            {
                                t = false;
                            }
                        }
                        if (t)
                        {
                            studente.Add(p);
                        }
                    }
                    else
                    {
                        studente.Add(p);
                    }
                    if (t) 
                    {
                        listBox1.Items.Add(p.ToString());
                    }
                    else
                    {
                        MessageBox.Show("Studente già inserito", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Studente.NMatricola--;
                    }
                }
            }
            else
            {
                MessageBox.Show("non sono stati inseriti corretamente i parametri", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
